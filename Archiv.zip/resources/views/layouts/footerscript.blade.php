
<script src="{{ url('/') }}/js/classie.js"></script>
<script src="{{ url('/') }}/js/pathLoader.js"></script>
<script src="{{ url('/') }}/js/main.js"></script>
<script src="{{ url('/') }}/js/pace.js"></script>



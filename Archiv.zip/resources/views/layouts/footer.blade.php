<footer class="footer">

  <p class="lead text-center">&copy;  2017 PaderMeet | <a href="/impressum">Impressum</a> |
  <a href="/locations">Locations </a> |
  <a href="/faq">FAQ</a> </p>
</footer>

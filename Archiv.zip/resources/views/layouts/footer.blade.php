<footer class="footer">

  <p class="lead text-center">&copy;  2017 TreffApp | <a href="/impressum">Impressum</a> |
  <a href="/participants">Locations </a> |
  <a href="/participants">FAQ</a> </p>
</footer>

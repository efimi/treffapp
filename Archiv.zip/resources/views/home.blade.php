@extends('layouts.master_static')

@section('content')
<div class="container">
    <div class="row">
        <div class="">
            <div class="panel panel-default">


                <div class="">
                    Du bist eingeloggt!
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <?php $__currentLoopData = $all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="locations/<?php echo e($location->id); ?>"><h1><?php echo e($location->name); ?></h1></a>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_static', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
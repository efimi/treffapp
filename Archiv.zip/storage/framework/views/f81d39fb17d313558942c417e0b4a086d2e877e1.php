<!DOCTYPE html>
<html lang="de">
  <head>
      <?php echo $__env->make('layouts.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </head>

  <body>
      <div id="ip-container" class="ip-container">
          <!-- initial header -->
          <header class="ip-header">
              <h1 class="ip-logo">
                  <svg class="ip-inner" width="100%" height="100%" viewBox="0 0 300 160" preserveAspectRatio="xMidYMin meet" aria-labelledby="logo_title">
                      <title id="logo_title">PaderMeet - Lerne neue Leute kennen.</title>
                            <?php echo $__env->make('layouts.logopath', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                    </svg>
                </h1>
                    <div class="ip-loader">
                      <svg class="ip-inner" width="60px" height="60px" viewBox="0 0 80 80">
                        <path class="ip-loader-circlebg" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
                        <path id="ip-loader-circle" class="ip-loader-circle" d="M40,10C57.351,10,71,23.649,71,40.5S57.351,71,40.5,71 S10,57.351,10,40.5S23.649,10,40.5,10z"/>
                      </svg>
                    </div>
            </header>

              <div class="ip-main">

                  <div class="container"> <!-- bootstrap container -->
                      <?php echo $__env->make('layouts.login_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                     <?php echo $__env->make('layouts.logo', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                     <?php echo $__env->yieldContent('content'); ?>

                     <?php echo $__env->make('layouts.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                   </div> <!-- /container -->

                   <!-- Bootstrap core JavaScript
                   ================================================== -->
                   <!-- Placed at the end of the document so the pages load faster -->
                   <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
                   


                </div> <!-- ip-main-->
            </div><!--  ip-container -->
            
            <?php echo $__env->make('layouts.footerscript', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
  </body>

</html>

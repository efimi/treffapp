<?php $__env->startSection('content'); ?>

  <div class="jumbotron">
    <p class="lead">Drücke auf den Button</p>
    <p class="lead">und finde heraus wo es heute für dich hingeht</p>

        <p>
            <?php if($location): ?>
              <div class="btn btn-lg btn-primary" role="button" id="button">  Wir warten auf dich :)  </div>
              <?php else: ?>
              <div class="btn btn-lg btn-primary" role="button" id="button" >  Let's Go!  </div>

              <?php endif; ?>
        </p>
  </div>

  <div class="jumbotron" id="resultview">
        <div id="database_entry">
                            <?php if($location): ?>
                              <p><?php echo e($location->name); ?></p>
                              <div><?php echo e($location->googlemaps_frame); ?></div>
                              <p>Heute 20:00</p>
                              <div id="current_matched">
                                 <?php // TODO: mit Mermkal from visitor->Location(location)->merkmale ?>
                                <?php if($location->used_places ==1): ?>
                                    <?php elseif($location->used_places == 2 ): ?>
                                        <p>Du bist nicht alleine!!:) Derzeit kommt noch eine weitere Person</p>
                                    <?php else: ?>
                                        <p>Derzeit kommen noch <?php echo e(($location->used_places)-1); ?> weitere Personen</p>
                                <?php endif; ?>
                              </div>
                            <?php endif; ?>
        </div>

    
  </div>

  <?php if(!$location): ?>
    <script src="js/buttonclick.js"></script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
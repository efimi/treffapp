<h1 class="ip-logo">
  <svg class="ip-inner" width="100%" height="100%" viewBox="0 0 300 160" preserveAspectRatio="xMidYMin meet" aria-labelledby="logo_title">
    <title id="logo_title">Pader Meet</title>
    <img src="images/logo.png" alt="">
  </svg>
</h1>

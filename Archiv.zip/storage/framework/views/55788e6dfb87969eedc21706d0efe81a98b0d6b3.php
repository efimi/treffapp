<section class="related">
  <p>If you enjoyed this demo you might also like:</p>
  <a href="http://tympanus.net/Development/HeaderEffects/">
    <!-- <img src="img/relatedposts/HeaderEffects.jpg" alt="Header Effects"/> -->
    <h3>On-Scroll Header Effects</h3>
  </a>
  <a href="http://tympanus.net/Development/ArticleIntroEffects/">
    <!-- <img src="img/relatedposts/ArticleIntroEffects.png" alt="Article Intro Effects" /> -->
    <h3>Article Intro Effects</h3>
  </a>
</section>

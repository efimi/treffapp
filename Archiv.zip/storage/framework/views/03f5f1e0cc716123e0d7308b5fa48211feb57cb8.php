


    <?php if(Auth::guest()): ?>
    
    <?php else: ?>
      <div class="header clearfix">
        <nav>
        <ul class="nav nav-pills float-right">
          <li class="nav-item">
            <a class="nav-link" href="/">Treffpunkte bearbeiten</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="/spieler">Treffpunkte anzeigenlassen</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="/table">Aktuelle Statistik</a>
          </li>

      <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('logout')); ?>"
               onclick="event.preventDefault();
                 document.getElementById('logout-form').submit();">
              Logout
            </a>

            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
              <?php echo e(csrf_field()); ?>

            </form>
          </li>
    <?php endif; ?>



  </ul>


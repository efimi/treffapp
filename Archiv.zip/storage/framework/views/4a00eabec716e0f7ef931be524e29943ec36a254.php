
<script src="<?php echo e(url('/')); ?>/js/classie.js"></script>
<script src="<?php echo e(url('/')); ?>/js/pathLoader.js"></script>
<script src="<?php echo e(url('/')); ?>/js/main.js"></script>
<script src="<?php echo e(url('/')); ?>/js/pace.js"></script>



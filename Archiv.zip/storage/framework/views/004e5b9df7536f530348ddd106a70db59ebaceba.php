<?php $__env->startSection('content'); ?>

  <div class="jumbotron no-margin no-padding-bottom">
    <p class="lead">Drücke auf den Button</p>
    <p class="lead">und finde heraus wo es heute für dich hingeht</p>

        <p>
            <?php if($location): ?>
              <button class="pushme" role="button" id="button" onclick="$('html, body').animate({
        scrollTop: $('#database_entry').offset().top
    }, 500);">  <span class="inner">Wir warten auf dich :) </span> </button>
              <?php else: ?>
                  <form class="" action="" method="post">
                     <label class="checkbox-inline" ><input type="checkbox" id="together">Wir kommen zu zweit.</label>
                  </form>
              <div class="pushme" role="button" id="button">  <span class="inner"> Let's Go! </span> </div>

              <?php endif; ?>
        </p>
  </div>

  <div class="jumbotron" id="resultview">
        <div id="database_entry">
                            <?php if($location): ?>
                              <h1><?php echo e($location->name); ?></h1>
                              <h3>Heute 20:00</h3>
                              <br>
                              <?php echo $__env->make('locations.map', $location, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                              <br>

                              <?php echo $__env->make('visitors.current', $location, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                            <?php endif; ?>
        </div>

    
  </div>
  <?php if(!$location): ?>
    <script src="js/buttonclick.js"></script>
  <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_loading', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
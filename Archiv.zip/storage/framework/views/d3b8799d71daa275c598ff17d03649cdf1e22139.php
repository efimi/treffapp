<div class="embed-responsive embed-responsive-16by9 col-xs-12 text-center">
      <iframe
      width="600"
      height="450"
      frameborder="0" style="border:0"
      src="https://www.google.com/maps/embed/v1/place?key=AIzaSyDCTKS-gFtXyWSKzXCu4ZxFbe6Mr6Tf2S8
        &q={<?php echo $location->address; ?>},Paderborn" allowfullscreen>
    </iframe>
</div>

<div id="current_matched">
   <?php // TODO: mit Mermkal from visitor->Location(location)->merkmale ?>
   <br>
  <?php if($location->used_places == 2): ?>
          <p>Du bist nicht alleine!!:) Derzeit kommt noch eine weitere Person</p>
      <?php elseif($location->used_places == 1): ?>
          
      <?php else: ?>
          <p>Derzeit kommen noch <?php echo e(($location->used_places)-1); ?> weitere Personen</p>
  <?php endif; ?>
</div>

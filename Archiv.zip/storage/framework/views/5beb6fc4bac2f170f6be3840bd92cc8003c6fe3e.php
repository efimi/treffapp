<?php $__env->startSection('content'); ?>
<div class="jumbotron">
    <a href="<?php echo e(url('/')); ?>/locations">zurück</a>
    <h2><?php echo e($location->name); ?></h2>
    <h2><?php echo e($location->address); ?></h2>
    <br>

    <?php echo $__env->make('locations.map', $location, array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <img class="embed-responsive embed-responsive-16by9 col-xs-12 text-center" src="<?php echo e($location->logo_path); ?>" alt="So sehen wir aus">
    <br>
    <h3>Geschlossen am <?php echo e($closed_on); ?></h3>
    <br>
    <a href="<?php echo e($location->url); ?>"> weitere Infos..</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master_static', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
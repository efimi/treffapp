<div class="logo-show">
    <a href="<?php echo e(url('/')); ?>"><img class="img-responsive" src="/img/logo.png" alt="logoPadermeet"></a>
</div>
